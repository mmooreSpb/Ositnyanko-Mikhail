# Находим наибольшую цифру целого числа
a = int(input("Введите любое целое цичло: "))
maximum = a % 10
a = a // 10
while a > 0:
    if a % 10 > maximum:
        maximum = a % 10
    a = a // 10
print(maximum)
