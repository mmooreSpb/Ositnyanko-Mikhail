# Определяем с каким финансовым результатом работает фирма
proceed = int(input("Введите выручку: "))
outlay = int(input("Введите издерку: "))
if proceed > outlay:
    profit = proceed - outlay
    rent = profit / proceed
    print(f"Отлично, ваша выручка составила {profit}")
    worker = int(input("Введите количество ваших работников >>> "))
    print(f"{profit / worker:.2f} - ваша прибыль на одного сотрудника")
elif proceed <= outlay:
    print(f"Нужно задуматься над лучшей реализацией вашего проекта")
