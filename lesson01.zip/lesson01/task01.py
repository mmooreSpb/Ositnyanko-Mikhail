# Работаем с переменными
int_num = int(input("Введите целое число >>> "))
any_num = float(input("Введи любое число >>> "))
words = (input("Напиши что захочешь >>> "))
# Выводим значения в формате столбца
print(int_num, any_num, words, sep='\n')
