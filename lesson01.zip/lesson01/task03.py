# Запрашиваем у пользователя число n
# и производим расчет алгоритма n + nn + nnn
n = int(input("Введите число: "))
num = str(n)
n1 = num + num
n2 = num + num + num
term = n + int(n1) + int(n2)
print(term)
